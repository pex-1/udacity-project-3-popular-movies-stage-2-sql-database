package udacity.popularmoviesstage1;

public class Constants {
    public static final String HTTPS_IMAGE_TMDB_ORG_T_P_W185 = "https://image.tmdb.org/t/p/w185";
    public static final String YOUTUBE_BASE_URL = "https://www.youtube.com/watch?v=";
}
